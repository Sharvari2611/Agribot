<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
  header("location: login.php");
  exit;
}
include 'partials/_dbconnect.php';
if ($_SERVER["REQUEST_METHOD"]=="GET"){

    $seedid=$_GET['sid'];
    $farmid=$_GET['farmid'];
    $_SESSION['farmid']=$farmid;
    $userid=$_SESSION['userid'];
    if (isset($farmid) && isset($seedid)){
    $sql="SELECT * FROM `seed` WHERE seedid='".$seedid."' AND userid='".$userid."'";
    $result= mysqli_query($conn,$sql);
    $row = mysqli_fetch_assoc($result);
        $seedgap=$row['seedgap'];
        $seeddepth=$row['seeddepth'];
        $seedname=$row['seedname'];
        $_SESSION['sname']=$seedname;
    $sql="SELECT `farmlength`,`farmwidth` FROM `farms` WHERE farmid='".$farmid."' AND userid ='".$userid."'";
    $result= mysqli_query($conn,$sql);
    $row = mysqli_fetch_assoc($result);
       $farmlength=$row['farmlength'];
       $farmwidth=$row['farmwidth'];
  }
  else{
    header("location:homepage.php");
  }
}
if ($_SERVER["REQUEST_METHOD"]=="POST"){

$userid= $_SESSION['userid'];
$sname=  $_SESSION['sname'];
$farmid=  $_SESSION['farmid'];
$sql="SELECT * FROM `seed` WHERE seedname='".$sname."' AND userid='".$userid."'";
$result= mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
    $seedgap=$row['seedgap'];
    $seeddepth=$row['seeddepth'];
    $seedname=$row['seedname'];
$sql="SELECT * FROM `users` WHERE username='".$_SESSION['username']."'";
$result= mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
    $userid=$row['userid'];
    $username=$row['username'];
    $phoneno=$row['phoneno'];
    $apikey=$row['apikey'];
$sql="SELECT `farmlength`,`farmwidth` FROM `farms` WHERE farmid='".$farmid."' AND userid ='".$userid."'";
$result= mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
   $farmlength=$row['farmlength'];
   $farmwidth=$row['farmwidth'];



              $sql="SELECT * FROM `finaldata` WHERE username='".$_SESSION['username']."'";
              $result=mysqli_query($conn,$sql);
              if ((mysqli_num_rows($result))<=0){
              $sql="INSERT INTO `finaldata`(`username`,`phoneno`,`apikey`,`seedname`, `seedgap`, `seeddepth`, `farmlength`, `farmwidth`)
              VALUES ('$username','$phoneno','$apikey','$seedname','$seedgap', '$seeddepth','$farmlength','$farmwidth')";
              $result=mysqli_query($conn,$sql);
            }
            else{
              $sql="DELETE FROM `finaldata` WHERE username='".$_SESSION['username']."'";
              $result=mysqli_query($conn,$sql);
              if($result){
                $sql="INSERT INTO `finaldata`(`username`,`phoneno`,`apikey`,`seedname`, `seedgap`, `seeddepth`, `farmlength`, `farmwidth`)
                VALUES ('$username','$phoneno','$apikey','$seedname','$seedgap', '$seeddepth','$farmlength','$farmwidth',)";
                $result=mysqli_query($conn,$sql);
              }
    }
    header("location:finalpage.php");
}


  ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Seed info</title>
  </head>
  <body>
    <!-- nav navbar-->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              About us
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="idea.php">Idea</a>
              <a class="dropdown-item" href="guide.php">Guide /Steps to follow </a>
            </div>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="/Agribot">Index Page<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="homepage.php">Home Page/a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">Logout</a>
          </li>
        </ul>
      </div>
    </nav>
      <br>
      <div class="container" >
    <div class="container">

     <h3 class="text-center">The details for the seed and farm are as follows</h3>
   </div>
      <form action="seed.php" method="post" id ="farmselect" text-center >

        <div class="form-group">
          <label for="sname" id="sname" name="sname"><h3><?php echo $seedname ?></h3></label>
       </div>

      <div class="form-group">
        <label for="sgap">Seed gap</label>
        <input type="text" class="form-control" id="sgap"   name="sgap" placeholder=" <?php echo $seedgap ?> cm"  readonly>
     </div>

     <div class="form-group">
       <label for="sdepth">Seed depth</label>
       <input type="text" class="form-control" id="sdepth" name="sdepth"  placeholder="<?php echo $seeddepth ?> cm" readonly>
    </div>

    <div class="form-group">
      <label for="flength">Farm Length</label>
      <input type="text" class="form-control" id="flength" name="flength"  placeholder=" <?php echo $farmlength?>m" readonly>
   </div>

   <div class="form-group">
     <label for="fwidth">Farm Width</label>
     <input type="text" class="form-control" id="fwidth" name="fwidth" placeholder="<?php echo $farmwidth ?> m" readonly>
  </div>
     <div class="form-group">
     <button type="submit" value="submit" class="btn btn-primary">Submit</button>
     </div>
   </form>
</div>
  </body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.0/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
