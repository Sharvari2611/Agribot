<?php
session_start();
if(!isset($_SESSION['loggedin'])||$_SESSION['loggedin']!=true)
{
    header("location:login.php");
    exit;
}
if (isset($_SESSION['success']))
{
  echo'<div class="alert alert-success alert-dismissible fade show" role="alert">
<strong>Success!</strong>'.$_SESSION['success'].'
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
  <span aria-hidden="true">&times;</span>
</button>
</div>';
unset($_SESSION['success']);
}
if (isset($_SESSION['error'])){
echo'
<div class="alert alert-warning alert-dismissible fade show" role="alert">
<strong>Sorry!</strong> Passwords do not match.
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>';
unset($_SESSION['error']);
}
include 'partials/_dbconnect.php';
$sql="SELECT * FROM `users` where username='" . $_SESSION['username'] . "'";
$result= mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);
$username=$row['username'];
$firstname=$row['firstname'];
$lastname=$row['lastname'];
$apikey=$row['apikey'];
$userid=$row['userid'];
$phoneno=$row['phoneno'];
$_SESSION['username']=$username;
$_SESSION['userid']=$userid;

?>
<!DOCTYPE html>
<html >
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<title>Welcome</title>
</head>
<body>

<!-- nav bar code-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="navbar-nav mr-auto">
      <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              About us
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="idea.php">Idea</a>
              <a class="dropdown-item" href="guide.php">Guide /Steps to follow </a>
            </div>
      </li>

      <li class="nav-item active ">
            <button type="button" class="btn btn-dark" onclick="window.location.href = '/Agribot'";data-toggle="modal" data-target="#exampleModal">
              Index
            </button>
      </li>


</ul>
<ul class="navbar-nav ml-auto">

  <li>
      <button type="button" onclick="window.location.href ='changepass.php'" class="btn btn-dark"  data-toggle="modal" data-target="#exampleModal">
      Change Password
      </button>
  </li>

  <li>
      <button type="button" onclick="window.location.href ='editprofile.php'" class="btn btn-dark"  data-toggle="modal" data-target="#exampleModal">
        Edit Profile
      </button>
  </li>
  <!-- Edit profile modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Edit details </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
    <form action="homepage.php" method="post" text-center>
              <div class="form-group">
                <label for="FName">First Name</label>
                <input type="text" class="form-control" id="fname" name="fname"  value="<?php echo $firstname ?>">
             </div>

             <div class="form-group">
               <label for="LName">Last Name</label>
               <input type="text" class="form-control" id="lname" name="lname" value="<?php echo $lastname ?>">
            </div>

            <div class="form-group">
              <label for="UName">UserName</label>
              <input type="text" class="form-control" id="uname" name="uname" value="<?php echo $username ?>" disabled>
           </div>

             <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="text" class="form-control" id="phno" name="phno" value="<?php echo $phoneno ?>">
             </div>

             <div class="form-group">
                <label for="apikey">API key</label>
                <input type="text" class="form-control" id="apikey" name="apikey" value="<?php echo $apikey ?>">
             </div>
            </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-dismiss="modal">Save changes</button>
        </div>
      </div>
    </div>
  </form>
  <!-- form submitted and profile edited-->
  </div>
<!-- edit profile ends-->
  <li>
    <div class="btn-group">
 <button type="button" class="btn btn-dark dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
   Delete details
 </button>
 <div class="dropdown-menu">
   <a class="dropdown-item" href="deletefarm.php">Delete farm</a>
   <a class="dropdown-item" href="deleteseed.php">Delete seed</a>
 </div>
</div>

  <li>
      <button type="button" onclick="window.location.href ='logout.php'" class="btn btn-dark">
       Logout
      </button>
   </li>
</ul>
</nav>
 <!-- nav bar ends heere-->

 <!-- Main home page begins here-->
<div class="container"><br>
  <center>
      <h3> Welcome -<?php echo $_SESSION['username'] ?> to the Website for Agricultural Bot</h3><br>
</center>
    <form  action="seed.php" method="get" text-center>
    <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
    Select Farm
   </a>
   <button type="button" onclick="window.location.href ='addseed.php';"class="btn btn-primary float-right mr-1" data-toggle="modal" data-target="#exampleModal1">
    Add Seed
  </button>
  <button type="button" onclick="window.location.href ='addfarm.php';" class="btn btn-primary float-right mr-1" data-toggle="modal" data-target="#exampleModal1">
    Add Farm
  </button> <br>
  <!-- farm details display-->
      <div class="collapse" id="collapseExample">
      <div class="card card-body">

      <?php
      include 'partials/_dbconnect.php';

           $sql="SELECT * FROM `farms` WHERE `userid`='".$_SESSION['userid']."'";
           if($result = mysqli_query($conn, $sql))
           {
             if(mysqli_num_rows($result) > 0)
              {
                while($row = mysqli_fetch_array($result))
                 {
                   $farmname=$row['farmname'];
                   $farmid=$row['farmid'];
                   $farmlength=$row['farmlength'];
                   $farmwidth=$row['farmwidth'];
        echo '<p>
        <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
    <li class="breadcrumb-item active" aria-current="page"><input type="radio" id="farmid" name="farmid" value='.$farmid.'> <label for="male">'.$farmname.': Dimensions : "'.$farmlength.' x '.$farmwidth.'"</label></p>
    </li>
    <li>
    <a href=deletefarm.php?farmid='.$farmid.' aligh-right>Delete</a>
    </li>
    </ol>
    </nav>';

        }
   }
 }
echo'
</div>
</div> ';
// farm details end here


 //   card code begins here
echo '<br>
<div class= row row-cols-2 row-cols-sm-2 row-cols-md-4" ">'
?>
<?php
if(isset($_SESSION['loggedin'])||$_SESSION['loggedin']==true)
{
    include 'partials/_dbconnect.php';
     $sql="SELECT * FROM `seed` WHERE `userid`='".$_SESSION['userid']."'";
  if($result = mysqli_query($conn, $sql))
    {
      if(mysqli_num_rows($result) > 0)
       {
         while($row = mysqli_fetch_array($result))
          {
            $sname=$row['seedname'];
            $sgap= $row['seedgap'];
            $sdepth=$row['seeddepth'];
            $sid=$row['seedid'];
  //card code
  echo'
<br>
<div class="col ">
  <div class="card" h-100">
    <div class="card-body">
      <h5 class="card-title">'.$sname.'</h5>
      <br>
      <p>This is a longer card with supporting text below as a natural lead-in to additional content. </p>
      <button type="submit" class="btn btn-primary" name="sid" value="'.$sid.'">Proceed</button>
      <a href=editseed.php?sid='.$sid.'>Edit</a>
      <a href=deleteseed.php?sid='.$sid.'>Delete</a>
    </div>
  </div>
</div>';}
  echo'
 </form>';
           mysqli_free_result($result);
      }
    else
        {
        echo'<div class="alert alert-warning alert-dismissible fade show" role="alert">
      <strong>Sorry!</strong> Rows not found.
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>';// rows finish
        }
   }
else
  {
    echo"query not executed";
  }
}
?>
</div>
</div>
<br>
</body>
</html>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
