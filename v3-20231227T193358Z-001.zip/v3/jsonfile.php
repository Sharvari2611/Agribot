<?php
if ($_SERVER["REQUEST_METHOD"]=="GET"){
    include 'partials/_dbconnect.php';
    $response=array();
    $apikeyfromesp=$_GET['api'];
    $sql="SELECT * FROM `finaldata` WHERE apikey='$apikeyfromesp'";
    $result= mysqli_query($conn,$sql);
    $row=mysqli_fetch_assoc($result);
    if($result){
      header("content-Type:JSON");
      $response['uname']=$row['username'];
      $response['phoneno']=$row['phoneno'];
      $response['sname']=$row['seedname'];
      $response['sgap']=$row['seedgap'];
      $response['sdepth']=$row['seeddepth'];
      $response['flength']=$row['farmlength'];
      $response['fwidth']=$row['farmwidth'];
      echo json_encode($response,JSON_PRETTY_PRINT);
    }
    else{
      mysqli_error($conn);
    }
  }
?>
