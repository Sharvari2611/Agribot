<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
  header("location: login.php");
  exit;
}
if ($_SERVER["REQUEST_METHOD"]=="GET"){
include 'partials/_dbconnect.php';
$farmid=$_GET['farmid'];
$sql="SELECT * FROM `farms` WHERE farmid='$farmid' AND userid='".$_SESSION['userid']."'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);
$farmname=$row['farmname'];
}

if ($_SERVER["REQUEST_METHOD"]=="POST"){
include 'partials/_dbconnect.php';
$farmid=$_POST['farmid'];
$userid=$_SESSION['userid'];
  $sql="DELETE FROM `farms` WHERE userid = '$userid' AND farmid='$farmid'";
  $result=mysqli_query($conn,$sql);
$_SESSION['success']="Farm deleted successfully";
header("location:homepage.php");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Delete farm</title>
  </head>
  <body>

  <div class="container">
    <br>
    <br>
  <div class="card text-center">

  <div class="card-header">
  <h4> Deleting <?php echo $farmname  ?></h4>
  </div>
  <form method="post">
  <div class="card-body">
    <p class="card-text">Are you sure you want to delete?</p>
    <input type="hidden" name="farmid" value="<?php echo $farmid ?>">
    <input type="submit" class="btn btn-primary"value="delete" name="Delete">
    <a href="homepage.php" class="btn btn-primary">Cancel</a>
  </div>
</div>
</form>

</div>
</body>
</html>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
