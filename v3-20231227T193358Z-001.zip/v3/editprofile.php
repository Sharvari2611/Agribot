<?php
session_start();
if(!isset($_SESSION['loggedin'])||$_SESSION['loggedin']!=true)
{
    header("location:login.php");
    exit;
}
if (isset($_SESSION['error'])){
  echo'
  <div class="alert alert-warning alert-dismissible fade show" role="alert">
<strong>Sorry!</strong>'.$_SESSION['error'].'
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
  <span aria-hidden="true">&times;</span>
</button>
</div>';
unset($_SESSION['error']);
}
include 'partials/_dbconnect.php';
if($_SERVER["REQUEST_METHOD"]=="GET"){
$sql="SELECT * FROM `users` where username='".$_SESSION['username']."'";
$result= mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);
$username=$row['username'];
$firstname=$row['firstname'];
$lastname=$row['lastname'];
$apikey=$row['apikey'];
$userid=$row['userid'];
$phoneno=$row['phoneno'];
}
if($_SERVER["REQUEST_METHOD"]=="POST"){
  $firstname=$_POST["fname"];
  $lastname=$_POST["lname"];
  $apikey=$_POST["apikey"];
  $phoneno=$_POST["phno"];
  $username=$_SESSION['username'];
  $sql="SELECT * FROM `users` WHERE `username` = '$username'";
  $result= mysqli_query($conn,$sql);
  $row=mysqli_fetch_assoc($result);
  $opass=$row['password'];
  if(strlen($_POST['fname'])<1 || strlen($_POST['lname'])<1 || strlen($_POST['phno'])<1 || strlen($_POST['apikey'])<1){
      $_SESSION['error']=" Enter all details";
      header("location:editprofile.php");
    }
    elseif (!is_numeric($_POST["phno"])){
       $_SESSION['error']=" Invalid phone number";
       header("location:editprofile.php");
    }

   else {
      $sql="UPDATE `users` SET  firstname = '$firstname', lastname='$lastname' ,phoneno='$phoneno', apikey='$apikey'
      WHERE username='".$_SESSION['username']."'";
      $result=mysqli_query($conn,$sql) or die(mysqli_error($conn));
      $_SESSION['success']=" Profile updated successfully";
      header("location:homepage.php");
}
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>edit profile</title>
  </head>
  <body>
<div class="container">
<form action="editprofile.php" method="post" text-center>
          <div class="form-group">
            <label for="FName">First Name</label>
            <input type="text" class="form-control" id="fname" name="fname"  value="<?php echo $firstname ?>">
         </div>

         <div class="form-group">
           <label for="LName">Last Name</label>
           <input type="text" class="form-control" id="lname" name="lname" value="<?php echo $lastname ?>">
        </div>

        <div class="form-group">
          <label for="UName">UserName</label>
          <input type="text" class="form-control" id="uname" name="uname" value="<?php echo $username ?>" disabled>
       </div>

         <div class="form-group">
            <label for="phone">Phone Number</label>
            <input type="text" class="form-control" id="phno" name="phno" value="<?php echo $phoneno ?>">
         </div>

         <div class="form-group">
            <label for="apikey">API key</label>
            <input type="text" class="form-control" id="apikey" name="apikey" value="<?php echo $apikey ?>">
         </div>

         <div class="form-group">
      <a href="homepage.php" class="btn btn-primary">Cancel</a>
      <button type="submit" class="btn btn-primary">Save changes</button>
</div>
</form>
</div>
</body>
</html>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
