<?php
session_start();
if(!isset($_SESSION['loggedin'])||$_SESSION['loggedin']!=true)
{
    header("location:login.php");
    exit;
}
if (isset($_SESSION['error'])){
  echo'
  <div class="alert alert-warning alert-dismissible fade show" role="alert">
<strong>Sorry!</strong>'.$_SESSION['error'].'
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
  <span aria-hidden="true">&times;</span>
</button>
</div>';
unset($_SESSION['error']);
}
include 'partials/_dbconnect.php';
if($_SERVER["REQUEST_METHOD"]=="POST"){
  $oldpass=$_POST["oldpass"];
  $pass=$_POST["pass"];
  $cpass=$_POST["cpass"];
  $username=$_SESSION['username'];
  $sql="SELECT * FROM `users` WHERE `username` = '$username'";
  $result= mysqli_query($conn,$sql);
  $row=mysqli_fetch_assoc($result);
  $opass=$row['password'];
  if (strlen($_POST['oldpass'])<1 || strlen($_POST['pass'])<1 || strlen($_POST['cpass'])<1){
      $_SESSION['error']=" Enter all details";
      header("location:changepass.php");
    }
    elseif ($oldpass!=$opass){
       $_SESSION['error']=" old password does not match";
       header("location:changepass.php");
    }
   elseif($pass!=$cpass){
     $_SESSION['error']=" New Password does not match";
     header("location:changepass.php");
   }
   else {
      $sql="UPDATE `users` SET password='$pass'  WHERE username='".$_SESSION['username']."'";
      $result=mysqli_query($conn,$sql) or die(mysqli_error($conn));
      $_SESSION['success']=" Password changed successfully";
      header("location:homepage.php");
}
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Delete farm</title>
  </head>
  <body>

  <div class="container">
    <br>
    <br>
  <div class="card text-center">

  <div class="card-header">
  <h4> Change Password</h4>
  </div>
  <form method="post">
  <div class="card-body">
    <div class="form-group">
      <label for="password">Old Password</label>
      <input type="password" class="form-control" id="oldpass"  name="oldpass" placeholder="Enter Old Password">
    </div>

    <div class="form-group">
      <label for="password"> New Password</label>
      <input type="password" class="form-control" id="pass"  name="pass" placeholder="Enter New Password">
    </div>

    <div class="form-group">
      <label for="CPassword">Confirm New Password</label>
      <input type="password" class="form-control" id="cpass" name="cpass" placeholder="Confirm New Password">
      <small id="cpass" class="form-text text-muted">Make sure you enter same password.</small>
    </div>

    <input type="submit" class="btn btn-primary" value="submit" name="Submit">
    <a href="homepage.php" class="btn btn-primary">Cancel</a>
  </div>
</div>
</form>

</div>
</body>
</html>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
