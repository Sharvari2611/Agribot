<?php
session_start();
if (isset($_SESSION['error'])){
  echo'
  <div class="alert alert-warning alert-dismissible fade show" role="alert">
<strong>Sorry!</strong>'.$_SESSION['error'].'
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
  <span aria-hidden="true">&times;</span>
</button>
</div>';
unset($_SESSION['error']);
}
$exists=false;
if ($_SERVER["REQUEST_METHOD"]=="POST")
{
  include 'partials/_dbconnect.php';
  $firstname=$_POST["fname"];
  $lastname=$_POST["lname"];
  $username=$_POST["uname"];
  $apikey=$_POST["apikey"];
  $phoneno=$_POST["phno"];
  $password=$_POST["pass"];
  $cpassword=$_POST["cpass"];

//  if(isset($_POST['fname']) && isset($_POST['lname']) && isset($_POST['uname']) && isset($_POST['phno']) && isset($_POST['apikey']) && isset($_POST['pass']) && isset($_POST['cpass']))
if(strlen($_POST['fname'])<1 || strlen($_POST['lname'])<1 || strlen($_POST['uname'])<1 || strlen($_POST['phno'])<1 || strlen($_POST['apikey'])<1 || strlen($_POST['pass'])<1 || strlen($_POST['cpass']) < 1){
    $_SESSION['error']=" Enter all details";
    header("location:signup.php");
  }
  elseif (!is_numeric($_POST["phno"])){
     $_SESSION['error']=" Invalid phone number";
     header("location:signup.php");
  }
 elseif($password!=$cpassword){
   $_SESSION['error']=" Passwords does not match";
   header("location:signup.php");
 }
 else {
   $sql="SELECT * FROM `users` WHERE `username` = '$username'";
   $result= mysqli_query($conn,$sql);
   $num=mysqli_num_rows($result);
   if($num>=1){
     $_SESSION['error']=" Username already exists";
     header("location:signup.php");
   }
   else{
   $sql="INSERT INTO `users` (`firstname`, `lastname`,`phoneno`,`apikey` ,`username`, `password`)
   VALUES ('$firstname', '$lastname', '$phoneno','$apikey','$username', '$password')";
   $result=mysqli_query($conn,$sql);
       sleep(1);
       $sql="SELECT * FROM `users` WHERE `username` = '$username'";
       $result=mysqli_query($conn,$sql);
       $row=mysqli_fetch_assoc($result);
       $userid= $row['userid'];
       $sql="INSERT INTO `seed` (`userid`, `seedname`,`seedgap`,`seeddepth`,`seeddes`)
       VALUES ('$userid', 'Jowar', '12','3','Its English name Sorghum, comes from the family it belongs to, Sorghum Vulgare.')";
       $result=mysqli_query($conn,$sql);

       $sql="INSERT INTO `seed` (`userid`, `seedname`,`seedgap`,`seeddepth`,`seeddes`)
       VALUES ('$userid', 'Wheat', '7','1','Wheat is a grass widely cultivated for its seed, a cereal grain which is a worldwide staple food.')";
       $result=mysqli_query($conn,$sql);

       $sql="INSERT INTO `seed` (`userid`, `seedname`,`seedgap`,`seeddepth`,`seeddes`)
       VALUES ('$userid', 'Ragi', '10','4','Ragi is an extremely nutritious millet, that resembles mustard seeds in appearance.')";
       $result=mysqli_query($conn,$sql);

       $sql="INSERT INTO `seed` (`userid`, `seedname`,`seedgap`,`seeddepth`,`seeddes`)
       VALUES ('$userid', 'Moong', '5','6','Moong/Mung or green gram are small, round, olive-green colored legumes with a sweet flavor.')";
       $result=mysqli_query($conn,$sql);
       $_SESSION['success']=" Profile created";
       header("location:login.php");
  }
 }
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <title>Signup</title>
  </head>
  <body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              About us
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="idea.php">Idea</a>
              <a class="dropdown-item" href="guide.php">Guide /Steps to follow </a>
            </div>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="/Agribot">Index Page<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="homepage.php">Home<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="login.php">Login<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="signup.php">Signup</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">Logout</a>
          </li>
        </ul>
      </div>
    </nav>

   <div class="container">
     <br>
     <h1 class="text-center">Sign up to create account</h1>
     <form action="signup.php" method="post" text-center>

     <div class="form-group">
       <label for="FName">First Name</label>
       <input type="text" class="form-control" id="fname" name="fname"placeholder="Enter First Name">
    </div>

    <div class="form-group">
      <label for="LName">Last Name</label>
      <input type="text" class="form-control" id="lname" name="lname" placeholder=" Enter Last Name">
   </div>

   <div class="form-group">
     <label for="UName">UserName</label>
     <input type="text" class="form-control" id="uname" name="uname" placeholder=" Set UserName">
  </div>

    <div class="form-group">
       <label for="phone">Phone Number</label>
       <input type="text" class="form-control" id="phno" name="phno" placeholder="Enter 10 digit phone number">
    </div>

    <div class="form-group">
       <label for="apikey">API key</label>
       <input type="text" class="form-control" id="apikey" name="apikey" placeholder="Enter the Product key mentioned on the device">
    </div>

     <div class="form-group">
       <label for="password">Password</label>
       <input type="password" class="form-control" id="pass"  name="pass" placeholder="Password">
     </div>

     <div class="form-group">
       <label for="CPassword">Confirm Password</label>
       <input type="password" class="form-control" id="cpass" name="cpass" placeholder="Confirm Password">
       <small id="cpass" class="form-text text-muted">Make sure you enter same password.</small>
     </div>
     <div class="form-group">
     <button type="submit" class="btn btn-primary">Submit</button>
        </div>
        </form>
    </div>
      </body>
</html>
