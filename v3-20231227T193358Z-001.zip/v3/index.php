<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link rel="stylesheet" href="css/flowchart.css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico" />
    <!-- Font Awesome icons (free version)-->
    <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
    <!-- Third party plugin CSS-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css" rel="stylesheet" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
</head>
    <title>home</title>
  <body id="page-top">
      <!-- Masthead-->
      <header class="masthead">
          <div class="container h-100">
              <div class="row h-100 align-items-center justify-content-center text-center">
                  <div class="col-lg-10 align-self-end">
                      <h1 class="text-uppercase text-white font-weight-bold">Automated Seed Sowing Machine</h1>
                      <hr class="divider my-4" />
                  </div>
                  <div class="col-lg-8 align-self-baseline">
                      <p class="text-white-75 font-weight-light mb-5">Start Bootstrap can help you build better websites using the Bootstrap framework! Just download a theme and start customizing, no strings attached!</p>
                      <a class="btn btn-primary btn-xl js-scroll-trigger" href="#about">Find Out More</a>
                  </div>
              </div>
          </div>
      </header>
      <!-- About-->
      <section class="page-section bg-primary" id="about">
          <div class="container">
              <div class="row justify-content-center">
                  <div class="col-lg-8 text-center">
                      <h2 class="text-white mt-0">Easy And Precise farming at your hand!</h2>
                      <hr class="divider light my-4" />
                      <p class="text-white-50 mb-4">Automatic seed sowing machine is a fully automated machine which can achieve various steps of farming  i.e. automatic drilling, seed sowing and compaction. These steps are achieved  with the help of user interface. Use of advanced technology such as the internet, GSM, and bluetooth are used to establish the connection between the machine and user.<br>
                        <br>
By signing up you'll be enabled to customize various parameters such as seed gap, seed depth, farm width, farm length and seed type. The user interface will also enable you to monitor the progress of your feild any time from anywhere.
<br>
<br> Sign up with us and experience this easy and Automated farming process just at click !</p>
                      <a class="btn btn-light btn-xl js-scroll-trigger" href="finalsignup.php">Signup</a>
                  </div>
              </div>
          </div>
      </section>
      <!-- Services-->
      <section class="page-section" id="services">
          <div class="container">
              <h2 class="text-center mt-0">The Process</h2>
              <div class="container">
                  <div class="row">
                      <div class="col-md-12">
                          <div class="main-timeline">
                              <div class="timeline">
                                  <div class="timeline-icon"><span class="year">1</span></div>
                                  <div class="timeline-content">
                                      <h3 class="title">Sign up / Login</h3>
                                      <p class="description">Create an account/ login with basic details and valid product key.The product key is provided with the machine.
                                      </p>
                                  </div>
                              </div>
                              <div class="timeline">
                                  <div class="timeline-icon"><span class="year">2</span></div>
                                  <div class="timeline-content">
                                      <h3 class="title">Parameter Selection</h3>
                                      <p class="description">Place the machine at the left corner of the farm. Enter details through website or through keypad present on the machine.</p>
                                  </div>
                              </div>
                              <div class="timeline">
                                  <div class="timeline-icon"><span class="year">3</span></div>
                                  <div class="timeline-content">
                                      <h3 class="title">Process Initiated</h3>
                                      <p class="description">After receiving data from the Website / Keypad, the machine will start working.In case of interruption you will be alerted via SMS.

                                      </p>
                                  </div>
                              </div>
                              <div class="timeline">
                                  <div class="timeline-icon"><span class="year">4</span></div>
                                  <div class="timeline-content">
                                      <h3 class="title">Hurray !</h3>
                                      <p class="description">
                                        Thus Precise farming is achieved by the Automated Seed Sowing Machine. This will improve your overall Agricultural yield.
                                      </p>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </section>
</body>
</html>
